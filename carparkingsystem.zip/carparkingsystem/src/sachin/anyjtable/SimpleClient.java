package sachin.anyjtable;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * socket客户端
 *
 */
public class SimpleClient {

    private final static String MESSAGE = "hello server";

    public static void main(String[] args) throws InterruptedException {

        Socket socket = null;
        OutputStream os = null;
        InputStream is = null;
        try {
            //与服务端建立socket连接，通过ip和端口号
            socket = new Socket("127.0.0.1", 1122);
            System.out.println("successed to connect to server");
            Scanner scanner = new Scanner(System.in);
            System.out.print("欢迎来到停车场，请输入您的车牌号:");
            String cph = scanner.nextLine();
            //获取输出流，向服务端发送数据
            os = socket.getOutputStream();
            //传输字符，一般情况下必须指定字符编码
            os.write(("0 "+cph).getBytes("UTF-8"));

            //此处需要关闭输出，否则服务端的读操作将一直循环下去
            socket.shutdownOutput();

            is = socket.getInputStream();

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] bt = new byte[256];
            int n = -1;
            //当客户端关闭其输出流时，read会返回-1
            while((n = is.read(bt)) != -1) {
                baos.write(bt, 0, n);
            }
            String sss = new String(baos.toByteArray(), "UTF-8");
            String [] sarray = sss.split(" ");
            String flag = sarray[0];
            //读取服务端返回的信息，用于判断停车状态,0代表成功停车
            if("0".equals(flag)) {
                System.out.println("已成功停车");
            }else {
                //当前无车位，主线程等待10秒后重新发一次停车请求
                Thread.sleep(10000);
                socket = new Socket("127.0.0.1", 1122);
                os = socket.getOutputStream();
                os.write(("0 "+cph).getBytes("UTF-8"));
                socket.shutdownOutput();
                is = socket.getInputStream();

                baos = new ByteArrayOutputStream();
                bt = new byte[256];
                n = -1;
                //当客户端关闭其输出流时，read会返回-1
                while((n = is.read(bt)) != -1) {
                    baos.write(bt, 0, n);
                }
                sss = new String(baos.toByteArray(), "UTF-8");
                sarray = sss.split(" ");
                flag = sarray[0];
                //
                if("0".equals(flag)) {
                    System.out.println("已成功停车");
                }else {
                    //等待10秒后无车位，自动离开停车场，客户端程序结束
                    System.out.println("无车位,离开停车场...");
                    return;
                }
                socket.close();
            }
            System.out.println("请输入任意键离开停车场:");
            String ns = scanner.nextLine();
            //System.out.println("message:" + new String(baos.toByteArray(), "UTF-8"));

            //关闭输入
            socket.shutdownInput();
            socket = new Socket("127.0.0.1", 1122);
            //cph = scanner.nextLine();
            //获取输出流，向服务端发送数据
            os = socket.getOutputStream();
            //传输字符，一般情况下必须指定字符编码
            os.write(("1 "+cph).getBytes("UTF-8"));

            //此处需要关闭输出，否则服务端的读操作将一直循环下去
            socket.shutdownOutput();
            is = socket.getInputStream();
            baos = new ByteArrayOutputStream();
            bt = new byte[256];
            //当客户端关闭其输出流时，read会返回-1
            while((n = is.read(bt)) != -1) {
                baos.write(bt, 0, n);
            }
            sss = new String(baos.toByteArray(), "UTF-8");
            System.out.println("离开停车场。。。");
            return;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(null != socket) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("finished...");
        }
    }
}