package sachin.anyjtable;

import java.util.*;

import javax.xml.crypto.Data;

/**
 * Description:
 *
 * @author Sachin 402948325@qq.com 2016��7��27��
 */
public class TestMain {
    public static List<String> list = new ArrayList<>();
    public static void main(String[] args) {
        Map<String, List<String>> catalogs = new HashMap<String, List<String>>();
        catalogs.put(SubjectFrame.DSCATALOGS, list);
        SubjectFrame frame = new SubjectFrame(catalogs);
        frame.setVisible(true);
        Thread t = new Thread(frame);
        t.start();
        Scanner s = new Scanner(System.in);
        while(true){
            System.out.println("请输入车牌号");
            String str = s.nextLine();
            list.add(str);
            frame.refreshTableActionPerformed();
        }

    }

}
