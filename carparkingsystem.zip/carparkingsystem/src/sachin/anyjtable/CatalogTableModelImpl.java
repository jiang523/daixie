package sachin.anyjtable;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;



/**
 * Description:
 * @author Sachin    402948325@qq.com
 * 2016年7月27日
 */
public class CatalogTableModelImpl implements TableModel {

    private List<String> infoList = new ArrayList<String>();
    String [] columName = new String[]{"车牌号"};
    public  CatalogTableModelImpl(List<String> infoList) {
        // TODO Auto-generated constructor stub
        this.infoList = infoList;
    }
    public  CatalogTableModelImpl() {
        // TODO Auto-generated constructor stub
    }


    @Override
    public int getRowCount() {
        // TODO Auto-generated method stub
        return infoList.size();
    }

    @Override
    public int getColumnCount() {
        // TODO Auto-generated method stub
        return columName.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        // TODO Auto-generated method stub
        return columName[columnIndex];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        // TODO Auto-generated method stub
        return String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        // TODO Auto-generated method stub
        String beanObj = infoList.get(rowIndex);
        String value = "";
        value = beanObj;
        if (value == null || (value != null && value.equals(""))) {
            value = " ";
        }

        return value;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        // TODO Auto-generated method stub

    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        // TODO Auto-generated method stub

    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        // TODO Auto-generated method stub

    }

}
