package sachin.anyjtable;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Administrator
 *
 */
public class SimpleServer implements Runnable {

    private final static String MESSAGE = "Hello Client";
    public static List<String> list = new ArrayList<>();//建立全局变量用于保存车牌号
    public static final int MAX_SIZE = 3;
    public static void main(String[] args) {
        /**
         * 将全局变量list传入jtable用于绘制停车信息
         */
        Map<String, List<String>> catalogs = new HashMap<String, List<String>>();
        catalogs.put(SubjectFrame.DSCATALOGS, list);
        SubjectFrame frame = new SubjectFrame(catalogs);
        frame.setVisible(true);
        Thread t = new Thread(frame);
        t.start();
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(1122);
            System.out.println("server started");
            Socket socket = null;

            while(true) {
                //通过accept获取一个Socket实例并建立一客户段的连接
                socket = serverSocket.accept();

                //获取输入流，读取客户端传输的数据
                InputStream is = socket.getInputStream();

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] bt = new byte[256];
                int n = -1;
                //当客户端关闭其输出流时，read会返回-1
                while((n = is.read(bt)) != -1) {
                    baos.write(bt, 0, n);
                }
                //关闭输入
                socket.shutdownInput();
                String s = new String(baos.toByteArray(), "UTF-8");
                //传输字符，一般情况下必须指定字符编码
                String [] ss = s.split(" ");
                OutputStream os = socket.getOutputStream();
                //0代表客户端发来的请求是停车请求，1代表的是离开请求
                if("0".equals(ss[0])) {
                    System.out.println("车牌号为:" +ss[1] +"申请停车位");
                    //当前停车总数小于最大停车容量，则直接停车，并给客户端返回停车成功信息
                    if(list.size()<MAX_SIZE) {
                        list.add(ss[1]);
                        System.out.println("成功停车，当前剩余车位"+(MAX_SIZE-list.size()));
                        os.write(("0 成功停车,当前车位:"+list.size()).getBytes("UTF-8"));
                        frame.refreshTableActionPerformed();
                        socket.shutdownOutput();
                        socket.close();
                    }else {
                        os.write("1 车位不足，请等待".getBytes("UTF-8"));
                        socket.shutdownOutput();
                        socket.close();
                    }
                }else {
                    list.remove(ss[1]);
                    System.out.println("当前剩余车位"+(MAX_SIZE-list.size()));
                    os.write((list.size()+"").getBytes());
                    socket.shutdownOutput();
                    socket.close();

                }

                //关闭socket
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(null != serverSocket) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("finished...");
        }
    }
    @Override
    public void run() {


    }
}
