package com.test;


import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import java.awt.Font;

public class UserLogin {

    /**登录跳转方法**/
    public static void login() {
        JFrame f = new JFrame("四则运算自测系统");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);

        //设置窗口的大小和位置
        f.setSize(500,316);
        f.setLocation(420,120);

        Container container = f.getContentPane();
        container.setLayout(null);

        JLabel label_userName = new JLabel("用户名: ");
        label_userName.setFont(new Font("宋体", Font.PLAIN, 30));
        label_userName.setBounds(54, 15, 137, 45);
        container.add(label_userName);

        JTextField textField_userName = new JTextField();
        textField_userName.setFont(new Font("宋体", Font.PLAIN, 26));
        textField_userName.setBounds(195, 21, 223, 29);
        container.add(textField_userName);

        JLabel label_password = new JLabel("密码  : ");
        label_password.setFont(new Font("宋体", Font.PLAIN, 30));
        label_password.setBounds(54, 63, 126, 29);
        container.add(label_password);

        JPasswordField passwordField_password = new JPasswordField();
        passwordField_password.setFont(new Font("宋体", Font.PLAIN, 26));
        passwordField_password.setBounds(195, 63, 223, 29);
        container.add(passwordField_password);


        //登录按钮  设定用户名：abc；密码：123
        JButton button_log = new JButton("登录");
        button_log.setFont(new Font("宋体", Font.PLAIN, 26));
        button_log.setBounds(107, 149, 100, 59);
        container.add(button_log);
        button_log.addActionListener(new ActionListener() {



            @Override
            public void actionPerformed(ActionEvent arg0) {
                //用户名或密码为空情况
                if (textField_userName.getText().trim().length() == 0 || new String(passwordField_password.getPassword()).trim().length() == 0) {
                    OptionPane.showMessage("用户名和密码不能为空");
                    return;
                }

                //用户名与密码符合
                if (textField_userName.getText().trim().equals("abc")&&new String(passwordField_password.getPassword()).trim().equals("123")) {
                    f.dispose();   //关闭当前登录界面
                    Settings.settings();  //跳转到设置界面
                    return;
                }

                //用户名和密码错误情况
                else {
                    OptionPane.showMessage("用户名或密码错误");
                    return;
                }

            }
        });


        JButton button_reset = new JButton("重置");
        button_reset.setFont(new Font("宋体", Font.PLAIN, 26));
        button_reset.setBounds(292, 149, 100, 59);
        container.add(button_reset);
        button_reset.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                textField_userName.setText("");
                passwordField_password.setText("");
            }
        });

    }  //void login

    public static void main(String[] args) {
        login();
    }

}

