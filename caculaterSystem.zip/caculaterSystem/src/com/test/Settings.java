package com.test;


import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;


public class Settings {
    protected static String m_modeOption;  //难度模式
    protected static int m_blankAmount;    //填空题数
    protected static int m_choiceAmount;   //选择题数
    protected static int m_judgeAmount;    //判断题数
    private static JTextField textField_notice;

    /**设置界面**/
    public static void settings() {
        JFrame f = new JFrame("设置");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        f.getContentPane().setLayout(null);
        f.setBounds(50, 50, 800, 500);

        Container container = f.getContentPane();



        JLabel label_mode = new JLabel("难度");
        label_mode.setFont(new Font("宋体", Font.PLAIN, 30));
        label_mode.setEnabled(false);
        label_mode.setBounds(79, 84, 67, 59);
        container.add(label_mode);

        //难度选择
        JComboBox comboBox_mode = new JComboBox();
        comboBox_mode.setFont(new Font("宋体", Font.PLAIN, 30));
        String [] modeOption = {" ", "简单", "困难"};
        comboBox_mode.setModel(new DefaultComboBoxModel(modeOption));
        comboBox_mode.setBounds(56, 158, 109, 47);
        container.add(comboBox_mode);

        JLabel lable_blank = new JLabel("填空题");
        lable_blank.setFont(new Font("宋体", Font.PLAIN, 25));
        lable_blank.setBounds(295, 105, 81, 21);
        container.add(lable_blank);

        JLabel label_choice = new JLabel("选择题");
        label_choice.setFont(new Font("宋体", Font.PLAIN, 25));
        label_choice.setBounds(295, 216, 81, 21);
        container.add(label_choice);

        JLabel label_judge = new JLabel("判断题");
        label_judge.setFont(new Font("宋体", Font.PLAIN, 25));
        label_judge.setBounds(295, 325, 81, 21);
        container.add(label_judge);

        JLabel label_amount = new JLabel("题目数量");
        label_amount.setFont(new Font("宋体", Font.PLAIN, 25));
        label_amount.setBounds(430, 41, 100, 27);
        container.add(label_amount);

        //题目数量选择
        String [] amountOption = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        JComboBox comboBox_balnk = new JComboBox();
        comboBox_balnk.setFont(new Font("宋体", Font.PLAIN, 25));
        comboBox_balnk.setEditable(false);
        comboBox_balnk.setModel(new DefaultComboBoxModel(amountOption));
        comboBox_balnk.setBounds(421, 99, 109, 27);
        container.add(comboBox_balnk);

        JComboBox comboBox_choice = new JComboBox();
        comboBox_choice.setFont(new Font("宋体", Font.PLAIN, 25));
        comboBox_choice.setEditable(false);
        comboBox_choice.setModel(new DefaultComboBoxModel(amountOption));
        comboBox_choice.setBounds(421, 215, 109, 27);
        container.add(comboBox_choice);

        JComboBox comboBox_judge = new JComboBox();
        comboBox_judge.setFont(new Font("宋体", Font.PLAIN, 25));
        comboBox_judge.setEditable(false);
        comboBox_judge.setModel(new DefaultComboBoxModel(amountOption));
        comboBox_judge.setBounds(421, 324, 109, 27);
        container.add(comboBox_judge);

        JButton button_confirm = new JButton("确认");
        button_confirm.setFont(new Font("宋体", Font.PLAIN, 25));
        button_confirm.setBounds(0, 397, 400, 47);
        button_confirm.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                m_modeOption = (String) comboBox_mode.getSelectedItem();  //获得难度模式
                m_blankAmount = Integer.parseInt(comboBox_balnk.getSelectedItem().toString());  //获得填空题数量
                m_choiceAmount = Integer.parseInt(comboBox_choice.getSelectedItem().toString()); //获得选择题数量
                m_judgeAmount = Integer.parseInt(comboBox_judge.getSelectedItem().toString());  //获得判断题数量
                f.dispose();
                if (comboBox_mode.getSelectedItem().equals("简单")) {
                    EasyFillBlank.doFillBlank();   //跳转至简单填空题页面
                }


                return ;
            }
        });
        container.add(button_confirm);

        JButton button_reset = new JButton("重置");
        button_reset.setFont(new Font("宋体", Font.PLAIN, 25));
        button_reset.setBounds(389, 397, 400, 47);
        button_reset.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                comboBox_mode.setSelectedItem(" ");
                comboBox_balnk.setSelectedItem("0");
                comboBox_choice.setSelectedItem("0");
                comboBox_judge.setSelectedItem("0");
            }
        });
        container.add(button_reset);

        JTextArea textArea_notice2 = new JTextArea("注意:\n 请务必点击\n 完提交后再\n 进入下一题");
        textArea_notice2.setBackground(Color.WHITE);
        textArea_notice2.setFont(new Font("Monospaced", Font.PLAIN, 28));
        textArea_notice2.setEditable(false);
        textArea_notice2.setBounds(555, 90, 174, 203);
        f.getContentPane().add(textArea_notice2);







    } //void settings()



    public static void main(String[] args) {
        settings();
    }
}//class Settings